# Starter Templates
A set of Photoshop and Sketch templates, designed to be imported into Framer Studio. These templates allow you to focus more on exploring concepts and ideas, and less on how to set-up your files. 

# Included resolutions
- iPhone 5
- iPhone 6
- iPad Mini
- iPad Air
- Nexus 5
- Nexus 9

# Importing in Framer
With Framer, you can bring your designs to life using tools you’re already comfortable with. If you’re not familiar with Importing, have a look at our [Importing Guide](http://framerjs.com/learn/import/).

# Previewing in Framer
To change the preview mode within Framer Studio, click on “Viewer” in the toolbar. Then, hover over “Device” and choose the device you’d like to preview your prototype within. 

————

If you need help, feel free to ask us anything in our [Community](https://www.facebook.com/groups/framerjs/). There are many people active in there (including us) that love to help you figure things out. 