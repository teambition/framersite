# Starter Templates
These templates are made to help you set up new projects, so you can start prototyping right away. They’re organised, labeled and designed for various iOS and Android devices. Including Sketch and Photoshop files.

## Designed for the following device resolutions:
- iPhone 5 and iPhone 6
- iPad Mini and iPad Air
- Nexus 5 and Nexus 9

### Importing in Framer
With Framer, you can bring your designs to life using tools you’re already comfortable with. If you’re not familiar with Importing, have a look at our [Importing Guide](http://framerjs.com/learn/import/) first.

### Previewing in Framer
To change the preview mode within Framer Studio, click on “Viewer” in the toolbar. Then, hover over “Device” and choose the device you’d like to preview your prototype within. 

————

If you need help, feel free to ask us anything in our [Community](https://www.facebook.com/groups/framerjs/). There are many people active in there (including us) that love to help you figure things out. 