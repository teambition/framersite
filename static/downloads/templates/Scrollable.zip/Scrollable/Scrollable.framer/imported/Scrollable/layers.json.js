window.__imported__ = window.__imported__ || {};
window.__imported__["Scrollable/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "3AF655BB-EF71-4027-ADEE-02DBFE5B89F7",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "210B5F3E-EDDA-45FE-A169-7E30A1029393",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "5FCE65B7-8C86-443D-90AD-1106EED6649D",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "BF9BC5FB-E545-4218-840C-47BF6EE9A2D1",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "544BDD49-EFF6-4158-8D1F-7F22F648708B",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Battery-544BDD49-EFF6-4158-8D1F-7F22F648708B.png",
                      "frame" : {
                        "y" : 11,
                        "x" : 690,
                        "width" : 49,
                        "height" : 19
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 11,
                      "x" : 690,
                      "width" : 49,
                      "height" : 19
                    },
                    "name" : "Battery"
                  }
                ],
                "image" : {
                  "path" : "images\/statusBar-BF9BC5FB-E545-4218-840C-47BF6EE9A2D1.png",
                  "frame" : {
                    "y" : 11,
                    "x" : 13,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 11,
                  "x" : 13,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "statusBar"
              }
            ],
            "image" : {
              "path" : "images\/navBarContent-5FCE65B7-8C86-443D-90AD-1106EED6649D.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 85
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 85
            },
            "name" : "navBarContent"
          }
        ],
        "image" : {
          "path" : "images\/navBar-210B5F3E-EDDA-45FE-A169-7E30A1029393.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 128
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 128
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "id" : "E7175CC5-2887-41E1-A3AE-2E7535CC161D",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "E5D25ECB-085B-44ED-BE58-D679D5AE736D",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/images-E5D25ECB-085B-44ED-BE58-D679D5AE736D.png",
              "frame" : {
                "y" : 161,
                "x" : 32,
                "width" : 688,
                "height" : 1888
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 161,
              "x" : 32,
              "width" : 688,
              "height" : 1888
            },
            "name" : "images"
          }
        ],
        "image" : {
          "path" : "images\/content-E7175CC5-2887-41E1-A3AE-2E7535CC161D.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/screen-3AF655BB-EF71-4027-ADEE-02DBFE5B89F7.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  }
]