window.__imported__ = window.__imported__ || {};
window.__imported__["Scrollable/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "EA2E254D-4F05-45F5-B120-33C145CE7923",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "4F6C52F3-361D-4F8B-9409-DB401171726B",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "A86820BD-4D5F-44EF-AEBB-21FEEF30391A",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "BA146373-5449-45E4-BD06-475A272B0A4B",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Battery-BA146373-5449-45E4-BD06-475A272B0A4B.png",
                      "frame" : {
                        "y" : 11,
                        "x" : 690,
                        "width" : 49,
                        "height" : 19
                      }
                    },
                    "imageType" : "png",
                    "layerFrame" : {
                      "y" : 11,
                      "x" : 690,
                      "width" : 49,
                      "height" : 19
                    },
                    "name" : "Battery"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-statusBar-A86820BD-4D5F-44EF-AEBB-21FEEF30391A.png",
                  "frame" : {
                    "y" : 11,
                    "x" : 13,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 11,
                  "x" : 13,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "statusBar"
              }
            ],
            "image" : {
              "path" : "images\/Layer-navBarContent-4F6C52F3-361D-4F8B-9409-DB401171726B.png",
              "frame" : {
                "y" : 11,
                "x" : 13,
                "width" : 726,
                "height" : 85
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 11,
              "x" : 13,
              "width" : 726,
              "height" : 85
            },
            "name" : "navBarContent"
          }
        ],
        "image" : {
          "path" : "images\/Layer-navBar-EA2E254D-4F05-45F5-B120-33C145CE7923.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 128
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 128
        },
        "name" : "navBar"
      },
      {
        "maskFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "id" : "9F5371E4-7ED6-4873-B2CD-3024EE67B9D7",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "40ADCC28-614E-42E0-A695-79CB82D8CF15",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/Layer-images-40ADCC28-614E-42E0-A695-79CB82D8CF15.png",
              "frame" : {
                "y" : 161,
                "x" : 32,
                "width" : 688,
                "height" : 1888
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 161,
              "x" : 32,
              "width" : 688,
              "height" : 1888
            },
            "name" : "images"
          }
        ],
        "image" : {
          "path" : "images\/Layer-content-9F5371E4-7ED6-4873-B2CD-3024EE67B9D7.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/Layer-screen-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "screen"
  }
]