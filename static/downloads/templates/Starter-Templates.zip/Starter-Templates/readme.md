# Starter Templates

A set of Photoshop and Sketch templates, designed to be imported into Framer Studio. These templates allow you to focus more on exploring concepts and ideas, and less on how to set-up your files. 

# Included device resolutions:
- iPhone 5
- iPhone 6
- iPad Mini
- iPad Air
- Nexus 5
- Nexus 9

————

If you need help, feel free to ask us anything in our [Community](https://www.facebook.com/groups/framerjs/). There are many people active in there (including us) that love to help you figure things out. 