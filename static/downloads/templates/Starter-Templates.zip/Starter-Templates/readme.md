# Starter Templates

A set of Photoshop and Sketch templates, designed to be imported into Framer Studio. These serve as great starting points for your next prototype.

# Included device resolutions:
- iPhone 5
- iPhone 6
- iPad Mini
- iPad Air
- Nexus 5
- Nexus 9

————

If you need help, feel free to ask us anything in our [Community](https://www.facebook.com/groups/framerjs/). There are many people active in there (including us) that love to help you figure things out. 